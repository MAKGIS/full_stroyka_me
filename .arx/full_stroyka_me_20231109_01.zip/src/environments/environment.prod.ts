export const environment = {
    production: true,
    pimalionCloudUrl: 'https://demo.sourcing.pm/backend',
    modeApp: 'demo.sourcing.pm',  // 'fake-server'; 'json'; 'demo.sourcing.pm',
    currencyCodePrice: 'EUR', // 'USD', 'EUR', 'GBP',
    rates:  {'EUR': 1, 'USD': 1.01},
    currentLang: 'fr'
};
