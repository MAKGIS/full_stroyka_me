import { Component } from '@angular/core';

@Component({
    selector: 'app-page-contact-us-alt',
    templateUrl: './page-contact-us-alt.component.html',
    styleUrls: ['./page-contact-us-alt.component.scss']
})
export class PageContactUsAltComponent {
    constructor() { }
}
