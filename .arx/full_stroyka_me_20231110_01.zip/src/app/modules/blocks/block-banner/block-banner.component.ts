import { Component } from '@angular/core';

@Component({
    selector: 'app-block-banner',
    templateUrl: './block-banner.component.html',
    styleUrls: ['./block-banner.component.scss']
})
export class BlockBannerComponent {

    tagLang = 'block-banner.';

    constructor() { }
}
