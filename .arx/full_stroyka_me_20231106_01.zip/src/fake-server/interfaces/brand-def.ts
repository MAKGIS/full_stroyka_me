export interface BrandDef {
    id?: string; // ???
    name: string;
    slug: string;
    image: string;
}
