import { NestedLink } from './nested-link';

export interface MegamenuColumn {
    size: number;
    items: NestedLink[];
}
