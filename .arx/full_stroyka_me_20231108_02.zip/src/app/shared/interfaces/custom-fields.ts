export interface CustomFields {
    [fieldName: string]: any;
}
