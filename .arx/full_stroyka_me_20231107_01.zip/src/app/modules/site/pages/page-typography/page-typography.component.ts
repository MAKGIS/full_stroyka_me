import { Component } from '@angular/core';

@Component({
    selector: 'app-typography',
    templateUrl: './page-typography.component.html',
    styleUrls: ['./page-typography.component.scss']
})
export class PageTypographyComponent {
    constructor() { }
}
