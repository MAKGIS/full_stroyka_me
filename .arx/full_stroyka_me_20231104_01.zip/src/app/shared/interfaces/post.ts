export interface Post {
    title: string;
    image: string;
    categories: string[];
    date: string;
}
